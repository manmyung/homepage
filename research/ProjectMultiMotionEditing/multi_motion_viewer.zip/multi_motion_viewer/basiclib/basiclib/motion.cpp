#include "motion.h"

using namespace basiclib;
//void Posture::set_globalSE3()
//{
//	set_globalSE3_traverse(p_skeleton->hierarchy_root, rootSE3);
//}
//
//void Posture::set_globalSE3_traverse(int bone, cml::SE3 prev_SE3)
//{
//	cml::SE3 next_SE3;
//
//	if (bone == p_skeleton->hierarchy_root)
//	{
//		next_SE3 = prev_SE3;
//	}
//	else
//	{
//		cml::vector3 local_transV(0.,0.,p_skeleton->bones[bone].length);
//		cml::SO3 so3_global = SO3s_global[bone];
//		cml::vector3 transV = so3_global * local_transV;
//		next_SE3 = prev_SE3 * getSE3ByTransV(transV);
//
//		SE3s_global[bone] = prev_SE3 * SO3_to_SE3(so3_global) * getSE3ByTransV(local_transV / 2.0);
//	}
//
//	typedef std::multimap<int, int>::const_iterator I;
//	std::pair<I,I> b = p_skeleton->hierarchy.equal_range(bone);
//	for (I i = b.first; i != b.second; ++i) {
//		set_globalSE3_traverse(i->second, next_SE3);
//	}
//}

void Posture::set_globalSE3()
{
	set_globalSE3_traverse(p_skeleton->hierarchy_root, rootSE3);
}

void Posture::set_globalSE3_traverse(int bone, cml::SE3 prev_SE3)
{
	cml::SE3 next_SE3;

	if (bone == p_skeleton->hierarchy_root)
	{
		next_SE3 = prev_SE3;
	}
	else
	{
		cml::vector3 local_transV(0.,0.,p_skeleton->bones[bone].length);
		SE3s_global[bone] = prev_SE3 * SO3_to_SE3(SO3s_local[bone]) * getSE3ByTransV(local_transV / 2.0);
		next_SE3 = SE3s_global[bone] * getSE3ByTransV(local_transV / 2.0);
	}

	typedef std::multimap<int, int>::const_iterator I;
	std::pair<I,I> b = p_skeleton->hierarchy.equal_range(bone);
	for (I i = b.first; i != b.second; ++i) {
		set_globalSE3_traverse(i->second, next_SE3);
	}
}