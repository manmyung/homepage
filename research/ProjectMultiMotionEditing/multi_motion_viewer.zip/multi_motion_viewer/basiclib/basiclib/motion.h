#pragma once

#include "cml_wrapper.h"

#include <map>
#include <vector>

namespace basiclib
{
	class Bone
	{
	public:
		double length;
	};

	class Skeleton
	{
	public:
		std::map<int, Bone>	bones;
		std::multimap<int, int>	hierarchy;
		std::map<int, int>	parent;
		int hierarchy_root;
	};

	class Posture
	{
	public:
		cml::SE3 rootSE3;
		//std::map<int, cml::SO3> SO3s_global;
		std::map<int, cml::SO3> SO3s_local;
		basiclib::Skeleton * p_skeleton;

		std::map<int, cml::SE3> SE3s_global;
		void set_globalSE3();

	private:
		void set_globalSE3_traverse(int bone, cml::SE3 prev_SE3);

	};


	typedef std::vector<basiclib::Posture> Motion;
}