#pragma once

#include <cassert>

#ifdef _DEBUG		
#define ASSERT(x) assert(x)
#else
#define ASSERT(x) 
#endif

#include <iostream>
using std::cout;
using std::endl;

#include <vector>

#include "cml_wrapper.h"