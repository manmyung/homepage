#pragma once

#include <iostream>
#include <vector>
#include <set>
#include <map>

namespace basiclib 
{
	template <typename T>
	void print(std::vector<T> &v)
	{
		std::vector<T>::iterator it;
		for (it = v.begin(); it != v.end(); it++ )
		{
			std::cout << *it << ' ';
		}
		std::cout << endl;
	}

	template <typename T>
	void print_line(std::vector<T> &v)
	{
		std::vector<T>::iterator it;
		for (it = v.begin(); it != v.end(); it++ )
		{
			std::cout << *it << endl;
		}
	}

}

template <typename T>
std::ostream& operator<<(std::ostream &os, std::vector<T> &v)
{
	std::vector<T>::iterator it;
	for (it = v.begin(); it != v.end(); it++ )
	{
		os << ' ' << *it;
	}
	return os;
}

template <typename T>
std::ostream& operator<<(std::ostream &os, const std::vector<T> &v)
{
	std::vector<T>::const_iterator it;
	for (it = v.begin(); it != v.end(); it++ )
	{
		os << ' ' << *it;
	}
	return os;
}

template <typename T>
std::ostream& operator<<(std::ostream &os, std::set<T> &v)
{
	std::set<T>::iterator it;
	for (it = v.begin(); it != v.end(); it++ )
	{
		os << ' ' << *it;
	}
	return os;
}

template <typename T>
std::ostream& operator<<(std::ostream &os, std::multimap<T, T> &v)
{
	std::multimap<T, T>::iterator it;
	for (it = v.begin(); it != v.end(); it++ )
	{
		os << it->first << " :" << endl << it->second << endl;
	}
	return os;
}

template <typename T>
std::ostream& operator<<(std::ostream &os, std::map<T, T> &v)
{
	std::map<T, T>::iterator it;
	for (it = v.begin(); it != v.end(); it++ )
	{
		os << it->first << " :" << endl << it->second << endl;
	}
	return os;
}

template <typename T>
T * make_array(std::vector<T> vec_T)
{
	T * arr = new T[vec_T.size()];
	copy( vec_T.begin(), vec_T.end(), arr);
	return arr;
}

template <class T>
class DivideValue {
private:
	double theValue;
public: 
	DivideValue(double &v) : theValue(v) {}
	void operator() (T &elem) const {
		elem /= theValue;
	}
};