#ifndef OBSERVER_H 
#define OBSERVER_H 
//========================================================= 
// observer.h 
// 
// Defines the Observer pattern. The Observer pattern 
// defines an one-to-many dependency between a subject 
// object and any number of observer objects so that 
// when the subject object changes state, all its 
// observer objects are notified and updated automatically. 
// 
// The Observer pattern is also known as Dependents and 
// Publish-Subscribe. 
// 
// The Observer pattern has four classes and they are: 
//  Observer 
//  Subject 
//  ConcreteObserver (child of Observer) 
//  ConcreteSubject (child of Subject) 
// 
// Both Observer and Subject class are generic and they can 
// be reused without modification. 
// 
// However ConcreteObserver and ConcreteSubject contains 
// many application specific information. Their class 
// framework can be reused with modificaiton. 
// 
//========================================================= 

#include <list> 
#include <iostream> 
#include <vector> 

using namespace std ; 

class Subject; 

//========================================================= 
// Observer class 
// 
// It defines the interface to attach with an object of 
// the type Subject. It's has to be subclassed in order 
// to be applied. It defines only the interface type. 
// 
// The function Update() is declared as virtual function 
// and has to be implemented in it's child class. The 
// Update() function is used by the Subject type object 
// for notifying state change. 
// 
//========================================================= 
class Observer { 
public: 
	Observer() {}; 
	~Observer() {}; 
	virtual void Update(Subject* theChangeSubject) = 0; 
}; 

//========================================================= 
// Subject class 
// 
// It defines the interface to attach with an object of 
// the type Observer. 
// 
// It can attach any number of the Observer type object. 
// It contains functions Attach() and Detach() to attach and 
// detach the Observer type object. 
// 
// The function Notify() calls function Update() located within 
// each of its attached Observer type objects. This function 
// is used whenever there is a state change and is 
// required to notify all of its Observer type objects. 
// 
//========================================================= 
class Subject { 
public: 
	Subject() {}; 
	~Subject() {}; 
	void Attach(Observer*); 
	void Detach(Observer*); 
	void Notify(); 
private: 
	vector<Observer*> _observers; 
}; 

#endif

