#pragma once

#include "baselib/baselib.h"
#include "baselib/motion/motionloader.h"

#include "basiclib/motion.h"

void getLinks(MotionLoader& loader, intvectorn& from, intvectorn & to );
void view_posture_3d(Motion& motion, int frame, intvectorn& index_from, intvectorn& index_to);
basiclib::Motion baselib_to_basiclib(Motion &motion);