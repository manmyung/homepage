#include "baselib_wrapper.h"
#include <GL/GLU.h> 
#include <FL/glut.H>
#include "basiclib/cml_wrapper.h"
#include "basiclib_gui/gl_wrapper.h"

void getLinks(MotionLoader& loader, intvectorn& from, intvectorn & to )
{
	NodeStack & stack=loader.m_TreeStack;

	stack.Initiate();

	Node *src=loader.m_pTreeRoot->m_pChildHead;	// dubasicliby���� ������.
	while(TRUE)
	{
		for(;src; src=src->m_pChildHead)
		{
			Node* child;
			for(child=src->m_pChildHead; child; child=child->m_pSibling)
			{
				//printf("%s %d -> %s %d\n", src->NameId, loader.GetIndex(src), child->NameId, loader.GetIndex(child));
				/*cout << loader.GetIndex(src) << " " << loader.GetIndex(child) << endl;*/
				from.pushBack(loader.GetIndex(src));
				to.pushBack(loader.GetIndex(child));

			}
			stack.Push(src);
		}
		stack.Pop(&src);
		if(!src) break;
		src=src->m_pSibling;
	}
}

GLUquadricObj *quadric = gluNewQuadric();
void view_posture_3d(Motion& motion, int frame, intvectorn& index_from, intvectorn& index_to)
{
	motion.setSkeleton(frame);
	vector3 v = motion.Pose(frame).front();
	cout << v[0] << ' ' << v[1] << ' ' << v[2] << ' ' << endl;

	for (int i = 0; i < index_to.size(); ++i) {
		Bone& bone0 = motion.skeleton().getBoneByTreeIndex(index_from[i]);
		//Bone& bone0 = motion.skeleton().getBoneByTreeIndex(1);
		matrix4 &mat0 = bone0.m_matCombined;

		Bone& bone1 = motion.skeleton().getBoneByTreeIndex(index_to[i]);
		//Bone& bone1 = motion.skeleton().getBoneByTreeIndex(2);
		matrix4 &mat1 = bone1.m_matCombined;

		cml::vector3 p0(mat0._14, mat0._24, mat0._34);
		cml::vector3 p1(mat1._14, mat1._24, mat1._34);
		cml::vector3 mid = (p1 + p0) / 2.0;

		cml::SE3 transf = getSE3ByTransV(mid);
		cml::SE3 rotate(
			mat0._11, mat0._12, mat0._13, 0,
			mat0._21, mat0._22, mat0._23, 0,
			mat0._31, mat0._32, mat0._33, 0,
			0,		0,		0,		1
			);

		vector3 offset_baselib;
		bone1.getOffset(offset_baselib);
		cml::vector3 offset(offset_baselib[0], offset_baselib[1], offset_baselib[2]);
		cml::vector3 rotV = between_vector(cml::vector3(0, 0, 1), offset);
		cml::SE3 rotate_bone = exp_SE3(rotV);

		double l = length(p1-p0);

		//cout << log_SO3(SO3(rotate*rotate_bone)) << endl;
		//bone�� global frame �� transf * rotate * rotate_bone
		draw_rect_parallelepiped(transf * rotate * rotate_bone, 0.07, 0.03, l*1.02);
	}
}

basiclib::Motion baselib_to_basiclib(Motion &motion)
{
	basiclib::Motion basiclib_motion;

	intvectorn index_from;
	intvectorn index_to;
	getLinks(motion.skeleton(), index_from, index_to);

	basiclib::Skeleton * p_skeleton = new basiclib::Skeleton();

	p_skeleton->hierarchy_root = index_from[0];
	for (int i = 0; i < index_to.size(); ++i) {
		::Bone& bone1 = motion.skeleton().getBoneByTreeIndex(index_to[i]);
		p_skeleton->bones[index_to[i]].length = bone1.length();
		p_skeleton->hierarchy.insert(std::make_pair(index_from[i], index_to[i]));
		p_skeleton->parent.insert(std::make_pair(index_to[i], index_from[i]));
	}

	/*for (std::multimap<int, int>::iterator itr = p_skeleton->hierarchy.begin();
		itr != p_skeleton->hierarchy.end(); ++itr)
	{
		cout << itr->first << ' ' << itr->second << endl;
	}*/

	for (int frame = 0; frame < motion.NumFrames(); ++frame)
	{
		basiclib::Posture posture;

		vector3 root_v = motion.Pose(frame).m_aTranslations[0];
		posture.rootSE3 = getSE3ByTransV(root_v[0], root_v[1], root_v[2]);

		motion.setSkeleton(frame);

		std::map<int, cml::SO3> SO3s_global;
		//root_local_SO3 ����
		SO3s_global[index_from[0]] = SE3_to_SO3(posture.rootSE3);
		
		for (int i = 0; i < index_to.size(); ++i) {
			::Bone& bone0 = motion.skeleton().getBoneByTreeIndex(index_from[i]);
			matrix4 &mat0 = bone0.m_matCombined;

			::Bone& bone1 = motion.skeleton().getBoneByTreeIndex(index_to[i]);
		
			cml::SO3 rotate(
				mat0._11, mat0._12, mat0._13,
				mat0._21, mat0._22, mat0._23,
				mat0._31, mat0._32, mat0._33
				);

			vector3 offset_baselib;
			bone1.getOffset(offset_baselib);
			cml::vector3 offset(offset_baselib[0], offset_baselib[1], offset_baselib[2]);
			cml::vector3 rotV = between_vector(cml::vector3(0, 0, 1), offset);
			cml::SO3 rotate_bone = exp_SO3(rotV);

			cml::SO3 so3 = rotate * rotate_bone;

			SO3s_global[index_to[i]] = so3;
			posture.SO3s_local[index_to[i]] = inverse(SO3s_global[index_from[i]]) * SO3s_global[index_to[i]];
		}

		posture.p_skeleton = p_skeleton;
		posture.set_globalSE3();
		basiclib_motion.push_back(posture);
	}

	//basiclib_motion[10].set_global();
	return basiclib_motion;
}