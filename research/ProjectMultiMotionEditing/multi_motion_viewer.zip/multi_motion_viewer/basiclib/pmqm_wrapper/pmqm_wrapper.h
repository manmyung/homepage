#pragma once

#include "PmQm/pm.h"
#include "basiclib_gui/fl_movie.h"

void draw_PmPosture(PmPosture &pose, double scale = 1.0); // ���� 0.027
PmLinearMotion * get_motion(char *actor_file, char *amc_file, int begin_frame = 0, int end_frame =0, double scale = 0.027); 
PmLinearMotion * get_bvhmotion(char *joint_map, char *bvh_file, double scale = 0.027);

void draw_quater(jhm::quater quat);

class Movie_pmqm : public Movie
{
public:
	Movie_pmqm(PmLinearMotion * motion_) {
		motion = motion_;
	}

	void draw(int frame) {
		draw_PmPosture(motion->getPosture(frame));
	}

	int num_frame() {
		return motion->getSize();
	}
private:
	PmLinearMotion * motion;
};

void stitch_motion(PmLinearMotion *head, PmLinearMotion *tail, int tail_begin_frame = 0, int tail_end_frame = 0);
void copy_motion(PmLinearMotion * to, PmLinearMotion * from, int from_begin_frame = 0, int from_end_frame = 0);

void adjust_foot_contraints_to_first_frame(PmLinearMotion * motion);
void adjust_foot_contraints_to_middle_frame(PmLinearMotion * motion);
void adjust_foot_contraints_to_middle_frame_new(PmLinearMotion * motion);

void setGlobalRotation(PmPosture &p, int i, jhm::quater cur_global);
void rotateGlobalRotation(PmPosture &p, int i, jhm::quater rotateQ);
void ik_limb_new(PmPosture &p, int i, jhm::vector newP, bool reverse = false);

cml::SE3 transf_to_SE3(jhm::transf &tf);


