#include <pmqm/pm.h>
#include "BVHReader.h"

#include <stack>
#include <fstream>
#include <algorithm>

using std::ifstream;
using std::string;

static char *kActorName = "temp.actor";

static char* human_part_name[PM_HUMAN_NUM_LINKS] =
{
	"PELVIS",
	"SPINE_1", "SPINE_2", "SPINE_3", "SPINE_4", "CHEST",
	"NECK", "HEAD",
	"RIGHT_SHOULDER", "LEFT_SHOULDER",
	"RIGHT_COLLAR", "LEFT_COLLAR",
	"UPPER_RIGHT_ARM", "UPPER_LEFT_ARM", "LOWER_RIGHT_ARM", "LOWER_LEFT_ARM",
	"UPPER_RIGHT_LEG", "UPPER_LEFT_LEG", "LOWER_RIGHT_LEG", "LOWER_LEFT_LEG",
	"RIGHT_FOOT", "LEFT_FOOT", "RIGHT_TOE", "LEFT_TOE",
	"RIGHT_PALM", "LEFT_PALM",
	"RIGHT_HEEL", "LEFT_HEEL",
	"RIGHT_FINGER_11", "RIGHT_FINGER_12", "RIGHT_FINGER_13",
	"RIGHT_FINGER_21", "RIGHT_FINGER_22", "RIGHT_FINGER_23",
	"RIGHT_FINGER_31", "RIGHT_FINGER_32", "RIGHT_FINGER_33",
	"RIGHT_FINGER_41", "RIGHT_FINGER_42", "RIGHT_FINGER_43",
	"RIGHT_FINGER_51", "RIGHT_FINGER_52", "RIGHT_FINGER_53",
	"LEFT_FINGER_11", "LEFT_FINGER_12", "LEFT_FINGER_13",
	"LEFT_FINGER_21", "LEFT_FINGER_22", "LEFT_FINGER_23",
	"LEFT_FINGER_31", "LEFT_FINGER_32", "LEFT_FINGER_33",
	"LEFT_FINGER_41", "LEFT_FINGER_42", "LEFT_FINGER_43",
	"LEFT_FINGER_51", "LEFT_FINGER_52", "LEFT_FINGER_53"
};

BVHReader::BVHReader(void)
{
}

BVHReader::~BVHReader(void)
{
}

int BVHReader::NewNode( const std::string &name, int parent )
{
	Node n(name, parent);
	int new_index = (int)nodes_.size();

	nodes_.push_back(n);
	
	std::map<std::string, int>::iterator it = joint_map_.find(name);
	if(joint_map_.end() == it) {
	//	std::cerr << "unknown joint : " << name << std::endl;
	}
	else {
		reverse_map_[ it->second ] = new_index;
	}


	if(parent >= 0) {
		nodes_[parent].children.push_back(new_index);
	}

	return new_index;
}

void BVHReader::AddChannel( int i, Node::Channel ch )
{
	nodes_[i].channels.push_back(std::make_pair(ch, 0.));
	channel_map_.push_back(std::make_pair(i, (int)nodes_[i].channels.size()-1));
}

void BVHReader::set_offset( int i, double x, double y, double z )
{
	nodes_[i].offset[0] = x;
	nodes_[i].offset[1] = y;
	nodes_[i].offset[2] = z;
}

std::string & BVHReader::Trim( std::string &str )
{

	// Trim Both leading and trailing spaces  
	size_t startpos = str.find_first_not_of(" \t"); 
	size_t endpos = str.find_last_not_of(" \t"); 

	if(string::npos == startpos) startpos = 0;
	if(string::npos == endpos) endpos = str.length()-1;
	str = str.substr(startpos, endpos-startpos+1);
   
	return str;
}

void BVHReader::MakeGlobal( int joint )
{
	for(int i=0; i < (int)nodes_[joint].children.size(); ++i) {
		int child = nodes_[joint].children[i];
		for(int j=0; j < 3; ++j) {
			nodes_[child].offset[j] += nodes_[joint].offset[j];
		}
		MakeGlobal(child);
	}
}

int BVHReader::GetParent( int joint )
{
	int parent = nodes_[joint].parent;
	if(parent < 0) return -1;

	std::map<std::string, int>::iterator it = joint_map_.find(nodes_[parent].name);
	if(joint_map_.end() == it) {
		return GetParent(parent);
	}
	else return it->second;
}
bool BVHReader::LoadJointMap( const std::string &fileName )
{
	joint_map_.clear();

	ifstream in(fileName.c_str());
	string pmJoint,jointName;

	while(in) {
		in >> pmJoint;
		std::getline(in,jointName);
		Trim(jointName);

		int jointIndex = -1;

		std::transform( pmJoint.begin(), pmJoint.end(), pmJoint.begin(), toupper );

		for(int i=0; i < PM_HUMAN_NUM_LINKS; ++i) {
			if( strcmp(human_part_name[i], pmJoint.c_str()) == 0 ) jointIndex = i;
		}
		if( jointIndex == -1) {
			std::cerr << "unknown PmQm part name : " << pmJoint << std::endl;
			return false;
		}
		joint_map_[jointName] = jointIndex;
	}

	return true;
}

bool BVHReader::OpenBVH( PmLinearMotion &mot, const std::string &fileName, double scale, bool loadHuman )
{
	std::ifstream in;

	in.open(fileName.c_str());

	std::string bufstr;

	std::stack<int> nodes;
	nodes.push(-1);
	int curNode = -1;

	reverse_map_.clear();
	nodes_.clear();
	channel_map_.clear();

	while(in) {
		in >> bufstr;

		if(bufstr == "ROOT") {
			std::getline(in, bufstr);
			Trim(bufstr);
			curNode = NewNode(bufstr, -1);
			continue;
		}
		if(bufstr == "OFFSET") {
			double x, y, z;
			in >> x >> y >> z;
			x *= scale;
			y *= scale;
			z *= scale;
			set_offset(curNode, x, y, z);
			continue;
		}
		if(bufstr == "CHANNELS") {
			int n;
			std::string bufstr2;
			in >> n;
			for(int i=0; i < n; ++i) {
				in >> bufstr2;
				if(bufstr2 == "Xrotation") AddChannel(curNode, Node::XROT);
				if(bufstr2 == "Yrotation") AddChannel(curNode, Node::YROT);
				if(bufstr2 == "Zrotation") AddChannel(curNode, Node::ZROT);

				if(bufstr2 == "Xposition") AddChannel(curNode, Node::XPOS);
				if(bufstr2 == "Yposition") AddChannel(curNode, Node::YPOS);
				if(bufstr2 == "Zposition") AddChannel(curNode, Node::ZPOS);
			}
			continue;
		}
		if(bufstr == "JOINT") {
			std::getline(in, bufstr);
			Trim(bufstr);
			curNode = NewNode(bufstr, curNode);
			continue;
		}
		if(bufstr == "End") {
			std::getline(in,bufstr);
			Trim(bufstr);
			curNode = NewNode(bufstr, curNode);
		}

		if(bufstr == "{") {
			nodes.push(curNode);
		}
		if(bufstr == "}") {
			nodes.pop();
			curNode = nodes.top();
		}
		if(bufstr == "MOTION") break;
	}

	MakeGlobal(0);

	if(loadHuman) {
		std::ofstream	os(kActorName);
		if (os.fail())	return false;

		os << "root_height\t" << nodes_[0].offset[1] << std::endl;

		double r_height = nodes_[ reverse_map_[PmHuman::RIGHT_FOOT] ].offset[1];
		double l_height = nodes_[ reverse_map_[PmHuman::LEFT_FOOT] ].offset[1];
		os << "ankle_height\t" << (l_height + r_height)/2.0 << std::endl;

		for (int i = 0; i < (int)nodes_.size(); i++)
		{
			std::map<std::string, int>::iterator it = joint_map_.find(nodes_[i].name);
			if(joint_map_.end() == it) {
				//				std::cerr << "Unknown joint : " << m_nodes[i].name << std::endl;
				continue;
			}
			int cur_joint = it->second;

			os << PmHuman::getLinkName(cur_joint) << std::endl;
			os << "begin" << std::endl;

			int	parent = GetParent(i);
			if (parent != -1)
				os << "\tparent\t" << PmHuman::getLinkName(parent) << std::endl;

			os << "\tcoordinate\t( ";
			for(int j=0; j < 3; ++j) {
				if(j) os << " , ";
				os << nodes_[i].offset[j];
			}
			os << " ) ( 1 , 0 , 0 , 0 )"<< std::endl;
			os << "end" << std::endl;
			os << std::endl;
		}

		os.close();
	}

	mot.setBody(new PmHuman(kActorName));

	int fcount;
	double ftime;
	in >> bufstr;
	in >> fcount;
	in >> bufstr;
	in >> bufstr;
	in >> ftime;

	mot.setSize(fcount);

	PmPosture hv;
	hv.setBody(mot.getBody());

	for(int i=0; i < fcount; ++i) {
		for(size_t j=0; j < channel_map_.size(); ++j) {
			double value;
			in >> value;
			nodes_[channel_map_[j].first].channels[channel_map_[j].second].second = value;
		}
		for(size_t j=0; j < nodes_.size(); ++j) {
			std::map<std::string, int>::iterator it = joint_map_.find(nodes_[j].name);
			if(joint_map_.end() == it) continue;
			int cur_joint = it->second;

			jhm::vector trans(0,0,0);
			jhm::quater q(1,0,0,0);
			for(size_t k=0; k < nodes_[j].channels.size(); ++k) {
				double value = nodes_[j].channels[k].second;
				switch(	nodes_[j].channels[k].first ) {
					case Node::XPOS:
						trans[0] += value *= scale;
						break;
					case Node::YPOS:
						trans[1] += value *= scale;
						break;
					case Node::ZPOS:
						trans[2] += value *= scale;
						break;
					case Node::XROT:
						// (value / 2) radian
						value = value / 360. * M_PI;
						q = q * jhm::exp( jhm::vector(value, 0, 0) );
						break;
					case Node::YROT:
						value = value / 360. * M_PI;
						q = q * jhm::exp( jhm::vector(0, value, 0) );
						break;
					case Node::ZROT:
						value = value / 360. * M_PI;
						q = q * jhm::exp( jhm::vector(0, 0, value) );
						break;
				}
			}
			if(cur_joint == PmHuman::PELVIS) hv.setTranslation(trans);
			hv.setRotation(cur_joint, q);
		}
		mot.setPosture(i, hv);
	}

	in.close();

	return true;
}
