#include "pmqm_wrapper.h"
#include "bvhreader.h"

#include "basiclib_gui/gl_wrapper.h"

#include "basiclib/basiclib.h"
#include "FL/glut.h"

#include <GL/GLU.h> 

void draw_bone(int parent_joint_i, jhm::vector& boneV, PmPosture const &pose)
{
	jhm::vector t = pose.getGlobalTranslation(parent_joint_i);
	jhm::vector rv = ln(pose.getGlobalRotation(parent_joint_i)) * 2;
	jhm::vector axis = normalize(rv);

	glPushMatrix();
	glTranslatef(t[0], t[1], t[2]);
	glRotatef( len( rv )*180/M_PI, axis[0], axis[1], axis[2] );

	//glutSolidSphere(0.034, 19, 19);
	cml::vector3 offset(boneV[0], boneV[1], boneV[2]);

	cml::vector3 rotV = between_vector(cml::vector3(0, 0, 1), offset);
	cml::SE3 translate_bone = getSE3ByTransV(offset / 2.0);
	cml::SE3 rotate_bone = exp_SE3(rotV);

	double posture_scale = pose.getBody()->getJointPosition(PmHuman::CHEST).length() / 0.273;
	//posture.getScale()�� ���� 1�̹Ƿ�, ����� ���� �� ������ scale�� ���� �� ����. �׷��Ƿ� ���̸� ���ؼ� scale�� �����ߴ�.

	draw_rect_parallelepiped(translate_bone * rotate_bone, 0.07 * posture_scale, 0.03 * posture_scale, length(offset)*1.02);
	glPopMatrix();
}

void draw_PmPosture(PmPosture &pose, double scale)
{
	glPushMatrix();
	glScaled(scale, scale, scale);
	PmHuman *human = pose.getBody();

	glEnable(GL_LIGHTING);

	for ( int i = 1; i<PM_HUMAN_NUM_LINKS; i++ )
	{
		if ( human->getMask() & MaskBit(i) )
		{
			draw_bone(human->getParent(i), human->getJointPosition(i), pose);
		}
	}

	draw_bone(PmHuman::LEFT_PALM,  jhm::vector(3,0,0) * 0.027 , pose);
	draw_bone(PmHuman::RIGHT_PALM, jhm::vector(-3,0,0) * 0.027 , pose);
	draw_bone(PmHuman::LEFT_TOE,   jhm::vector(0,0,3) * 0.027 , pose);
	draw_bone(PmHuman::RIGHT_TOE,  jhm::vector(0,0,3) * 0.027 , pose);
	draw_bone(PmHuman::NECK,  jhm::vector(0,4,0) * 0.027 , pose);

	glDisable(GL_LIGHTING);
	glPopMatrix();
}

PmLinearMotion * get_motion(char *actor_file, char *amc_file, int begin_frame, int end_frame, double scale)
{
	PmHuman* pm_human;
	PmLinearMotion* pm_motion;

	pm_human = new PmHuman(actor_file, scale); ASSERT(pm_human->getNumLinks() != 0);
	pm_motion = new PmLinearMotion(pm_human);

	if(pm_motion->openAMC_Woody(amc_file, scale) == -1)
	{
		cout << amc_file << " is wrong AMC file name!" << endl;
		ASSERT(false);
	}

	if (begin_frame == 0 && end_frame ==0) {
		//��� ��ü
	} 
	else {
		pm_motion->crop(*pm_motion, begin_frame, end_frame - begin_frame);
	}

	return pm_motion;
}

PmLinearMotion * get_bvhmotion( char *joint_mapping_file, char *bvh_file, double scale /*= 0.027*/ )
{
	PmLinearMotion* pm_motion;
	pm_motion = new PmLinearMotion();

	BVHReader reader;
	reader.LoadJointMap(joint_mapping_file);
	reader.OpenBVH(*pm_motion, bvh_file, scale, true);

	return pm_motion;
}

void draw_quater(jhm::quater quat)
{
	jhm::vector rv = ln(quat) * 2;
	jhm::vector axis = normalize(rv);

	glPushMatrix();
	glRotatef( len( rv )*180/M_PI, axis[0], axis[1], axis[2] );
	draw_fine_axis();
	glPopMatrix();
}

//stitch �ϸ� 1 frame �� ��ġ�� ������ �پ���.
void stitch_motion(PmLinearMotion *head, PmLinearMotion *tail, int tail_begin_frame, int tail_end_frame)
{
	if (tail_begin_frame == 0 && tail_end_frame == 0)
	{
		head->stitchWithWarp(*tail);
	}
	else
	{
		PmLinearMotion temp_motion;
		temp_motion.crop(*tail, tail_begin_frame, tail_end_frame - tail_begin_frame);
		head->stitchWithWarp(temp_motion);
	}
}

void copy_motion(PmLinearMotion * to, PmLinearMotion * from, int from_begin_frame, int from_end_frame)
{
	if (from_begin_frame == 0 && from_end_frame == 0)
	{
		from_end_frame = from->getSize();
	}

	to->setBody(from->getBody());
	to->crop(*from, from_begin_frame, from_end_frame-from_begin_frame);
}

void adjust_foot_contraints_to_first_frame(PmLinearMotion * motion)
{
	for ( int i=1; i<(int)motion->getSize(); i++ )
	{
		if ( motion->getConstraint(i-1).isConstrained(PmHuman::LEFT_FOOT) &&
			motion->getConstraint(i).isConstrained(PmHuman::LEFT_FOOT) )
		{
			motion->getConstraint(i).setTransf(PmHuman::LEFT_FOOT, 
				motion->getPosture(i-1).getTransf(PmHuman::LEFT_FOOT));
		}

		if ( motion->getConstraint(i-1).isConstrained(PmHuman::RIGHT_FOOT) &&
			motion->getConstraint(i).isConstrained(PmHuman::RIGHT_FOOT) )
		{
			motion->getConstraint(i).setTransf(PmHuman::RIGHT_FOOT, 
				motion->getConstraint(i-1).getTransf(PmHuman::RIGHT_FOOT));
		}
	}
}

void adjust_foot_contraints_to_middle_frame(PmLinearMotion * motion)
{
	std::vector<int> boundary_con;
	//int j = PmHuman::RIGHT_FOOT;
	for(int  j=0; j<PM_HUMAN_NUM_LINKS; j++ )
	{
		if (j == PmHuman::RIGHT_FOOT || j == PmHuman::LEFT_FOOT)
		{
			for(int i = 0; i < motion->getSize(); ++i)
			{
				if (motion->constraints[i].isConstrained(j) == true)
				{
					boundary_con.push_back(i);
					while(true) {
						++i;
						if (i == motion->getSize() || motion->constraints[i].isConstrained(j) == false)
							break;
					}
					boundary_con.push_back(i-1);
				}
			}

			for(int i = 0; i < boundary_con.size(); i += 2)
			{
				int before_i = boundary_con[i];
				int after_i = boundary_con[i+1];

				int middle_i = (before_i + after_i) / 2;

				for (int ii = before_i; ii <= after_i; ++ii)
				{
					motion->getConstraint(ii).setTransf(j, motion->getConstraint(middle_i).getTransf(j));
				}

			}
		}
	}
}

void adjust_foot_contraints_to_middle_frame_new(PmLinearMotion * motion)
{
	std::vector<int> boundary_con;
	//int j = PmHuman::RIGHT_FOOT;
	for(int  j=0; j<PM_HUMAN_NUM_LINKS; j++ )
	{
		if (j == PmHuman::RIGHT_FOOT || j == PmHuman::LEFT_FOOT)
		{
			for(int i = 0; i < motion->getSize(); ++i)
			{
				if (motion->constraints[i].isConstrained(j) == true)
				{
					boundary_con.push_back(i);
					while(true) {
						++i;
						if (i == motion->getSize() || motion->constraints[i].isConstrained(j) == false)
							break;
					}
					boundary_con.push_back(i-1);
				}
			}

			for(int i = 0; i < boundary_con.size(); i += 2)
			{
				int before_i = boundary_con[i];
				int after_i = boundary_con[i+1];

				int middle_i = (before_i + after_i) / 2;

				for (int ii = before_i; ii <= after_i; ++ii)
				{
					jhm::transf &tran = motion->getPosture(middle_i).getGlobalTransf(j);
					jhm::vector vec = tran.getTranslation();
					vec[1] = 0.05;
					tran.setTranslation(vec);
					motion->getConstraint(ii).setTransf(j, tran);
				}

			}
		}
	}
}

void setGlobalRotation(PmPosture &p, int i, jhm::quater cur_global)
{
	jhm::quater parent_global = p.getGlobalRotation(p.getBody()->getParent( i ));
	jhm::quater cur_joint = (p.getBody()->getJointTransf(i)).getRotation();

	jhm::quater new_local = cur_joint.inverse() * parent_global.inverse() * cur_global;
	p.setRotation(i, new_local);
}

void rotateGlobalRotation(PmPosture &p, int i, jhm::quater rotateQ)
{
	setGlobalRotation(p, i, rotateQ * p.getGlobalRotation(i));
}

void ik_limb_new( PmPosture &p, int i, jhm::vector newP, bool reverse /*= false*/ )
{
	int palm = i;
	int lower = p.getBody()->getParent( palm );
	int upper = p.getBody()->getParent( lower );

	jhm::vector B = p.getGlobalTranslation(palm);
	jhm::vector C = p.getGlobalTranslation(lower);
	jhm::vector A = p.getGlobalTranslation(upper);

	//error ó��
	if ((B - newP).length() < 0.000001)
		return;

	jhm::vector L = B - A;
	jhm::vector N = B - C;
	jhm::vector M = C - A;

	double l = L.length();
	double n = N.length();
	double m = M.length();

	double a = ACOS((l*l + n*n - m*m) / (2*l*n));
	double b = ACOS((l*l + m*m - n*n) / (2*l*m));

	jhm::vector B_new = newP;
	jhm::vector L_new = B_new - A;

	double l_ = L_new.length();

	double a_ = ACOS((l_*l_ + n*n - m*m) / (2*l_*n));
	double b_ = ACOS((l_*l_ + m*m - n*n) / (2*l_*m));

	//���� �ʱⰪ������ �ݴ�� ���̴� ��찡 ����� �̸� �ݴ�� ����
	if (reverse == true)
	{
		a_ *= -1.0;
		b_ *= -1.0;
	}

	jhm::vector rotV = M * L;
	rotV /= rotV.length();

	double rotb = b - b_;
	double rota = a_ - a - rotb;

	//���󿡼� ȸ���ؼ� ���߱�
	rotateGlobalRotation(p, upper, exp(rotV * rotb / 2));
	rotateGlobalRotation(p, lower, exp(rotV * rota / 2));

	//���ۿ��� ȸ���ؼ� ���߱�
	jhm::vector rotV2 = L * L_new;
	rotV2 /= rotV2.length();

	double l_new = L_new.length();
	double l_diff = (L_new - L).length();

	double rot2 = ACOS((l_new * l_new + l * l - l_diff * l_diff) / (2 * l_new * l));
	rotateGlobalRotation(p, upper, exp(rotV2 * rot2 / 2));
}

cml::SE3 transf_to_SE3(jhm::transf &tf)
{
	cml::SE3 se3 = getSE3ByTransV(tf.getTranslation().x(), tf.getTranslation().y(), tf.getTranslation().z());

	jhm::matrix tf_matrix = tf.getAffine();
	se3(0,0) = tf_matrix[0][0];
	se3(0,1) = tf_matrix[1][0];
	se3(0,2) = tf_matrix[2][0];
	se3(1,0) = tf_matrix[0][1];
	se3(1,1) = tf_matrix[1][1];
	se3(1,2) = tf_matrix[2][1];
	se3(2,0) = tf_matrix[0][2];
	se3(2,1) = tf_matrix[1][2];
	se3(2,2) = tf_matrix[2][2];

	return se3;
}

