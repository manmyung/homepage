﻿#pragma once

#include <string>
#include <map>
#include <vector>

/// BVH 파일을 PmLinearMotion 으로 읽어들이기 위한 클래스
class BVHReader
{
public:
	BVHReader(void);
	~BVHReader(void);

	/// joint map을 읽어들인다.
	bool LoadJointMap(const std::string &fileName);
	
	/// BVH 파일을 읽는다.
	/**
		@param mot 모션을 저장할 PmLinearMotion 인스턴스
		@param fileName BVH 파일 이름
		@param scale 길이를 결정한다.
		@param loadHuman true로 주어질 경우 mot의 PmHuman 인스턴스도 생성한다.
	*/
	bool OpenBVH(PmLinearMotion &mot, const std::string &fileName, double scale, bool loadHuman );

protected:
	struct Node
	{
		Node(const std::string &n, int p) : name(n), parent(p) {}

		enum Channel { XPOS = 1, YPOS, ZPOS, ZROT, XROT, YROT };

		int parent;
		std::string name;
		std::vector<int> children;
		std::vector<std::pair<Channel, double> > channels;
		double offset[3];

	};

	std::string &Trim(std::string &str);

	int NewNode(const std::string &name, int parent);
	void AddChannel(int i, Node::Channel ch);
	void set_offset(int i, double x, double y, double z);

	void MakeGlobal(int joint);
	int GetParent(int joint);

	std::map<std::string, int>	joint_map_;
	std::map<int, int>	reverse_map_;

	std::vector<Node> nodes_;
	std::vector<std::pair<int, int> > channel_map_;



};
