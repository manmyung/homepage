// test.cpp
#include <UnitTest++.h>

TEST(FailSpectacularly)
{
	CHECK(true);
}

int main()
{
	return UnitTest::RunAllTests();
}
