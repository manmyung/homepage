#include "motion_gui.h"

void view_posture(basiclib::Posture &posture)
{
	//draw_rect_parallelepiped(transf * rotate * rotate_bone, 0.07, 0.03, l*1.02);
	//draw_ellipsoid(posture.rootSE3, 0.1, 0.1, 0.1);
	for(std::map<int, cml::SE3>::iterator it = posture.SE3s_global.begin();
		it != posture.SE3s_global.end(); ++it)
	{
		//draw_rect_parallelepiped(getSE3ByTransV(0, 1, 0), 1.07, 0.03, 1.);
		draw_rect_parallelepiped(it->second, 0.07, 0.03, posture.p_skeleton->bones[it->first].length);
	}
}