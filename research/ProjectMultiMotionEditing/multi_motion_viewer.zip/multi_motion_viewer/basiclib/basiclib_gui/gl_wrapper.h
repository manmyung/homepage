#pragma  once

#include "basiclib/cml_wrapper.h"

void draw_rect_parallelepiped(cml::SE3 se3, double length_x, double length_y, double length_z);
void draw_rect_parallelepiped(cml::SE3 se3, double length);
void draw_ellipsoid(cml::SE3 se3, double length_x, double length_y, double length_z);

void un_project(int mouse_x, int h_minus_mouse_y, cml::vector3 &line_p, cml::vector3 &line_v);

void draw_axis();
void draw_fine_axis();

void setupShadow();
void unsetupShadow();