#include "gl_wrapper.h"
#include "FL/glut.h"
#include <GL/GLU.h> 

void draw_rect_parallelepiped(cml::SE3 se3, double length_x, double length_y, double length_z)
{
	glPushMatrix();

	glMultMatrixd(se3.data());
	glScaled(length_x, length_y, length_z);
	glutSolidCube(1);
	
	glPopMatrix();
}

void draw_rect_parallelepiped(cml::SE3 se3, double length)
{
	draw_rect_parallelepiped(se3, length, length*0.3, length*0.1);
}

void draw_ellipsoid(cml::SE3 se3, double length_x, double length_y, double length_z)
{
	glPushMatrix();

	glMultMatrixd(se3.data());
	glScaled(length_x, length_y, length_z);
	glutSolidSphere(0.5, 23, 23);

	glPopMatrix();
}

void un_project(int mouse_x, int h_minus_mouse_y, cml::vector3 &line_p, cml::vector3 &line_v)
{
	GLdouble mvmatrix[16], projmatrix[16];
	GLint viewport[4];

	glGetDoublev(GL_MODELVIEW_MATRIX, mvmatrix);
	glGetDoublev(GL_PROJECTION_MATRIX, projmatrix);
	glGetIntegerv(GL_VIEWPORT, viewport);

	GLdouble wx, wy, wz;
	gluUnProject((GLdouble)mouse_x, (GLdouble)h_minus_mouse_y, 0.25, mvmatrix, projmatrix, viewport, &wx, &wy, &wz);
	cml::vector3 p1(wx, wy, wz);
	gluUnProject((GLdouble)mouse_x, (GLdouble)h_minus_mouse_y, 0.75, mvmatrix, projmatrix, viewport, &wx, &wy, &wz);
	cml::vector3 p2(wx, wy, wz);

	line_p = p1;
	line_v = p2 - p1;
}

void draw_axis()
{
	glBegin(GL_LINES);
	glColor3f(1,0,0);
	glVertex3f(1.0,0,0);
	glVertex3f(0,0,0);
	glColor3f(0,1,0);
	glVertex3f(0,1.0,0);
	glVertex3f(0,0,0);
	glColor3f(0,0,1);
	glVertex3f(0,0,1.0);
	glVertex3f(0,0,0);
	glEnd();
}

void draw_fine_axis()
{
	glEnable(GL_LIGHTING);
	glColor3d(1,0,0);
	cml::SE3 trans_x = getSE3ByTransV(0.5, 0, 0);
	draw_rect_parallelepiped(trans_x, 1, .05, .05);
	draw_ellipsoid(trans_x*trans_x, 0.1, 0.1, 0.1);
	glColor3d(0,1,0);
	cml::SE3 trans_y = getSE3ByTransV(0.0, 0.5, 0);
	draw_rect_parallelepiped(trans_y, .05, 1, .05);
	draw_ellipsoid(trans_y*trans_y, 0.1, 0.1, 0.1);
	glColor3d(0,0,1);
	cml::SE3 trans_z = getSE3ByTransV(0.0, 0.0, 0.5);
	draw_rect_parallelepiped(trans_z, .05, .05, 1);
	draw_ellipsoid(trans_z*trans_z, 0.1, 0.1, 0.1);
	glDisable(GL_LIGHTING);
}

void setupShadow()
{
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glEnable(GL_STENCIL_TEST);
	glStencilFunc(GL_EQUAL,0x1,0x1);
	glStencilOp(GL_KEEP,GL_ZERO,GL_ZERO);
	glStencilMask(0x1);		// only deal with the 1st bit

	glPushMatrix();
	// a matrix that squishes things onto the floor
	//float sm[16] = {1,0,0,0, 0,0,0,0.0, 0,0,1,0, 0,0.0,0,1};
	double light1_x = 10.0;
	double light1_y = -10.0;
	double light1_z = 20.0;

	float sm[16] = {1,0,0,0, -(light1_x/light1_z) ,0,-(light1_y/light1_z),0, 0,0,1,0, 0,0,0,1};
	glMultMatrixf(sm);
	// draw in transparent black (to dim the floor)
	glColor4f(0,0,0,.5);
}

void unsetupShadow()
{
	glPopMatrix();
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_STENCIL_TEST);
	glDisable(GL_BLEND);
}