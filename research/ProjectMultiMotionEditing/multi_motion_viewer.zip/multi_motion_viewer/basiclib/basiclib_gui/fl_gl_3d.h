#pragma once

#include "basiclib/cml_wrapper.h"
#include "basiclib/basiclib.h"

#include <FL/glut.H>
#include <GL/GLU.h> 

#include <FL/Fl_Gl_Window.H>

class Camera
{
public:
	double centerX;
	double centerY;
	double centerZ;
	double rotateY;
	double rotateX;
	double distance;

	Camera::Camera()
	{
		centerX = 0.0;
		centerY = 0.8;
		centerZ = 0.0;
		rotateY = deg2Rad(0.0);
		rotateX = deg2Rad(-15.0);
		distance = 7.0;
	}

	void set_2d()
	{
		centerX = 0.0;
		centerY = 0.0;
		centerZ = 0.0;
		rotateY = deg2Rad(-90.0);
		rotateX = deg2Rad(-90.0);
		distance = 5.0;
	}
	cml::SE3 getSE3() 
	{
		cml::SE3 SE3_1 = getSE3ByTransV(centerX, centerY, centerZ);
		cml::SE3 SE3_2 = getSE3ByRotY(rotateY);
		cml::SE3 SE3_3 = getSE3ByRotX(rotateX);
		cml::SE3 SE3_4 = getSE3ByTransV(0, 0, distance);
		cml::SE3 se3 = SE3_1 * SE3_2 * SE3_3 *SE3_4;

		return se3;
	}

	void transform() {
		cml::matrix44d_c se3 = getSE3();
		glMultMatrixd(inverse(se3).data());
	}
};


class Fl_gl_3d : public Fl_Gl_Window 
{
public:
	Fl_gl_3d(int x,int y,int w, int h, const char *l=0);

	Camera camera;

	bool Is_draw_ground() const { return is_draw_ground; }
	void Is_draw_ground(bool val) { is_draw_ground = val; }

	bool Is_draw_axis() const { return is_draw_axis; }
	void Is_draw_axis(bool val) { is_draw_axis = val; }

protected:
	virtual int handle(int event);
	void initialize_gl();
	void init_gl_color();
	void setupFloor();
	virtual void draw();

	bool is_draw_ground;
	bool is_draw_axis;
	
	int mousePrevX;
	int mousePrevY;

	bool press_2;
	bool press_3;
};
