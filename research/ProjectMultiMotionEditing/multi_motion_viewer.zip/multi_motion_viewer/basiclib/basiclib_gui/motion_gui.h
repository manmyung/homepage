#pragma  once

#include "basiclib/motion.h"
#include "gl_wrapper.h"

void view_posture(basiclib::Posture &posture);