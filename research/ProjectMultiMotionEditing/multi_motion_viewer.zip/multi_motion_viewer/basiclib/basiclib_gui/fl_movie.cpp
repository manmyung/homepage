#include "fl_movie.h"

void Fl_gl_3d_parent::draw()
{
	Fl_gl_3d::draw();
	((Fl_movie *) p_parent)->draw_();
}

int Fl_gl_3d_parent::handle(int event)
{
	int return1 = Fl_gl_3d::handle(event);
	int return2 = ((Fl_movie *) p_parent)->handle_(event);

	//Motion_edit_win �ȿ��� flush�� �ϸ� ȭ�� ������Ʈ�� �ȵǼ� �̷��� �Ѵ�.��� �����־���.
	if (return2 == 1)
		flush();

	return (return1 || return2);
}

void staticTimer_view(void* p)
{
	((Fl_movie*)p)->timer();
}

Fl_movie::Fl_movie(int x, int y, int w, int h, Movie * movie_, const char *l) : frame_rate(30), Fl_Window(x,y,w,h,l)
{
	movie = movie_;
	init(movie->num_frame());
}

Fl_movie::Fl_movie(int x, int y, int w, int h, const char *l) : frame_rate(30), Fl_Window(x,y,w,h,l) {
	
}

void Fl_movie::init(int num_frame)
{
	if (num_frame == 0)
		num_frame = 1;
	fl_gl_3d_parent = new Fl_gl_3d_parent(0, 0, w(), h()-30, this);

	view_button = new Fl_Button(0, h()-30, 40, 30);
	view_button->label("@> / @||");
	view_button->callback(staticCallBack_view, (void*)this); 
	view_button->value(1);

	view_slider = new Fl_Value_Slider(40, h()-30, w() -40, 30);
	view_slider->type(FL_HORIZONTAL);
	view_slider->value(0);
	view_slider->step(1);
	view_slider->bounds(0, num_frame-1);
	view_slider->callback(staticCallBack_view, (void*)this);

	staticTimer_view(this);
	show();	
}

void Fl_movie::set_frame(int num_frame)
{
	view_slider->bounds(0, num_frame-1);
}

void Fl_movie::staticCallBack_view(Fl_Widget* w, void* p)
{
	((Fl_movie*)p)->CallBack(w);
}

void Fl_movie::CallBack(Fl_Widget* w)
{
	if( w == view_button)
	{
		if (view_button->value() == 1)
			view_button->value(0);
		else
			view_button->value(1);
	}
	else if (w == view_slider)
	{
		fl_gl_3d_parent->redraw();
	}
}

void Fl_movie::draw_()
{
	int frame = int(view_slider->value());
	movie->draw(frame);
}

int Fl_movie::handle_(int event)
{
	return 0;
}

void Fl_movie::timer()
{
	if (view_button->value() == 1) {
		int frame = int(view_slider->value());
		view_slider->value(frame+1);

		if (view_slider->value() > view_slider->maximum()) 
			view_slider->value(0);
	}
	fl_gl_3d_parent->redraw();
	idle();

	Fl::add_timeout(1.0 / double(frame_rate) * 0.83, (Fl_Timeout_Handler)staticTimer_view, this);
}

Fl_movies::Fl_movies(int x, int y, int w, int h, std::vector<Movie *> movies_, const char *l) :Fl_movie(x,y,w,h,l)
{
	movies = movies_;

	int num_frame = 0;
	for (int i = 0; i < movies.size(); ++i)
		if (num_frame < movies[i]->num_frame())
			num_frame = movies[i]->num_frame();

	init(num_frame);
}

void Fl_movies::draw_()
{
	int frame = int(view_slider->value());
	for (int i = 0; i < movies.size(); ++i)
	{
		if (frame <= movies[i]->num_frame() -1)
			movies[i]->draw(frame);
	}
}
