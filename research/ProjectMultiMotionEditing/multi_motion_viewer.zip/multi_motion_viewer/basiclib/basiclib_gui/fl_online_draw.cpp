#include "fl_online_draw.h"

void Fl_gl_online_draw::draw()
{
	Fl_gl_3d::draw();
	((Fl_online_draw *) p_parent)->draw_();
}

int Fl_gl_online_draw::handle(int event)
{
	int return1 = Fl_gl_3d::handle(event);
	int return2 = ((Fl_online_draw *) p_parent)->handle_(event);

	// ������ ������ �־� �ּ�ó���Ͽ���.
	//if (return2 == 1)
	//	flush();

	return (return1 || return2);
}

void staticTimer_online_draw(void* p)
{
	((Fl_online_draw*)p)->timer();
}

Fl_online_draw::Fl_online_draw(int x, int y, int w, int h, const char *l) : frame_rate(30), Fl_Window(x,y,w,h,l) {
	init();
}

void Fl_online_draw::init()
{
	fl_gl_3d_parent = new Fl_gl_online_draw(0, 0, w(), h(), this);
	staticTimer_online_draw(this);
	show();	
}

int Fl_online_draw::handle_(int event)
{
	return 0;
}

void Fl_online_draw::timer()
{
	tick();
	fl_gl_3d_parent->redraw();
	Fl::add_timeout(1.0 / double(frame_rate) * 0.83, (Fl_Timeout_Handler)staticTimer_online_draw, this);
}