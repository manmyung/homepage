#pragma once

#include "fl_gl_3d.h"

class Fl_gl_online_draw : public Fl_gl_3d
{
public:
	Fl_gl_online_draw(int x,int y,int w, int h, void * const p_parent_, const char *l=0): Fl_gl_3d(x, y, w, h, l), p_parent(p_parent_) {}

	void * p_parent;
	void draw();
	int handle(int event);
};

class Fl_online_draw : public Fl_Window 
{
public:
	Fl_online_draw(int x, int y, int w, int h, const char *l=0);

	virtual void draw_() {}
	virtual int handle_(int event);
	virtual void tick() {}

	Camera& get_camera() { return fl_gl_3d_parent->camera; }
	Fl_gl_online_draw * fl_gl_3d_parent;

	int Frame_rate() const { return frame_rate; }
	void Frame_rate(int val) { frame_rate = val; }

	void timer();

protected:
	void init();
	static void staticCallBack_view(Fl_Widget* w, void* p);

	int frame_rate;
};
