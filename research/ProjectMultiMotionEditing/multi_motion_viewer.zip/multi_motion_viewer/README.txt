* How to compile
1. Install Visual Studio 2010
2. Open multi_motion_viewer.sln
3. Compile multi_motion_viewer project

* Camera control
Mouse right button : rotation
Mouse middle button : translation
Mouse middle wheel : distance

* How to select motions
Comment or Uncomment the lines of the motion_load function in main.cpp

* How to manipulate motions
See motion_load_and_manipulate function in main.cpp

* Question
If you have any question about this program, feel free to contact Manmyung Kim (manmyung@gmail.com).
