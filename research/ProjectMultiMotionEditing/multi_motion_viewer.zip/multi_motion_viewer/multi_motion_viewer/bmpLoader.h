#ifndef _BMP_LOADER_H
#define _BMP_LOADER_H

#include <stdio.h>

/* Image type - contains height, width, and data */
struct Image {
    unsigned long sizeX;
    unsigned long sizeY;
    unsigned char *data;
};
typedef struct Image Image; 

unsigned int getint(FILE *fp);
unsigned int getshort(FILE *fp);
int ImageLoad(const char *filename, Image *image);
int ImageSave(char *filename, Image *image);

#endif