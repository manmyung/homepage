#ifndef _BITMAP_H_
#define _BITMAP_H_

#include <windows.h>

#define BITMAP_ID 0x4D42

unsigned char *LoadBitmapFile(const char *filename, BITMAPINFOHEADER *bitmapInfoHeader);

#endif