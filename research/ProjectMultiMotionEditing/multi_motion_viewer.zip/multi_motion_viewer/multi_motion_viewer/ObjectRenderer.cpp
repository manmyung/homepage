#include "ObjectRenderer.h"
#include <windows.h>
#include <gl/gl.h>
#include <gl/glut.h>

#include <iostream>

ObjectRenderer::ObjectRenderer(void)
{
	m_chairListIndex = -1;
	m_yugo45ListIndex = -1;
	m_flightListIndex = -1;
	m_benchListIndex = -1;
}

ObjectRenderer::~ObjectRenderer(void)
{

}

void ObjectRenderer::Render( TYPE type, bool color )
{	
	if(type == SOLID_CUBE) glutSolidCube(1);
	else if(type == SOLID_SPHERE) glutSolidSphere(1, 20, 20);
	else if(type == CHAIR) {
		if(m_chairListIndex == -1) LoadChair();
		glCallList(m_chairListIndex);
	}
	else if (type == YUGO_45){
		if(m_yugo45ListIndex == -1) LoadYugo();
		if(color) glEnable(GL_TEXTURE_2D);
		glCallList(m_yugo45ListIndex);
		glDisable(GL_TEXTURE_2D);
	}
	else if(type == BENCH)
	{
		if(m_benchListIndex == -1) LoadBench();
		if(color) glEnable(GL_TEXTURE_2D);
		glCallList(m_benchListIndex);
		glDisable(GL_TEXTURE_2D);
	}
}  

void ObjectRenderer::LoadChair()
{
	m_chair.createModel("../data/model/model_txt_files/","chair");
	m_chairListIndex = glGenLists(1);
	glNewList(m_chairListIndex, GL_COMPILE);
	glScaled(0.001, 0.001, 0.001);
	m_chair.displayModel();
	glEndList();

}

void ObjectRenderer::LoadYugo()
{
	m_yugo45.loadObjFile("../data/model/model_obj_files/Yugo45.obj");
	m_yugo45.loadTexture("../data/model/model_bmp_files/Yugo45.bmp");
	float* model_center = m_yugo45.model_center;
	m_yugo45ListIndex = glGenLists(1);
	glNewList(m_yugo45ListIndex, GL_COMPILE);
	glScalef(0.1, 0.1 , 0.1);
	glTranslatef(model_center[0],model_center[1],model_center[2]);
	m_yugo45.displayModelWithTexture();
	glEndList();

}

void ObjectRenderer::LoadBench()
{
 	m_bench.loadObjFile("../data/model/model_obj_files/hut.obj");
 	m_bench.loadTexture("../data/model/model_bmp_files/hut.bmp");
 	m_benchListIndex = glGenLists(1);
 	glNewList(m_benchListIndex, GL_COMPILE);
 	glRotatef(-90, 1, 0, 0);
	glRotatef(90, 0, 0, 1);
 	glScalef(0.20, 0.20 , 0.1);
 	m_bench.displayModelWithTexture();
 	glEndList();
}