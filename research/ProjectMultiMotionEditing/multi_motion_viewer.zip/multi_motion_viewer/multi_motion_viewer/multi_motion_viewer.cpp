#include "multi_motion_viewer.h"
#include "basiclib_gui/gl_wrapper.h"
#include "ObjectRenderer.h"

Multi_motion_viewer::Multi_motion_viewer(Multi_motion *mm_) : Fl_movie(100, 100, 1024, 768)
{
	mm = mm_;

	init(mm->get_last_frame() + 1);
	show();	

	get_camera().distance = 15.0;
	get_camera().rotateX = deg2Rad(-40.0);
	Frame_rate(mm->frame_rate);
}

Multi_motion_viewer::~Multi_motion_viewer( void )
{

}

void Multi_motion_viewer::draw_()
{
	int frame = int(view_slider->value());

	//shadow 
	for (std::vector<Motion>::iterator iter = mm->m_motions.begin(); iter != mm->m_motions.end(); ++iter)
	{
		setupShadow();
		if (frame >= iter->get_first_frame() && frame <= iter->get_last_frame())
			draw_motion(*iter, frame, false);
		unsetupShadow();
	}

	//real
	for (std::vector<Motion>::iterator iter = mm->m_motions.begin(); iter != mm->m_motions.end(); ++iter)
	{
		if (frame >= iter->get_first_frame() && frame <= iter->get_last_frame())
			draw_motion(*iter, frame, true);
	}
}

void Multi_motion_viewer::draw_motion( Motion &motion, double frame, bool colorful)
{
	if(colorful == true)
		glColor4dv(motion.m_color);
	
	if (motion.m_is_human == true)
	{
		PmPosture p = motion.m_pm_motion->getPosture(frame - motion.frame_offset);
		draw_PmPosture(p, 1.0);
	}
	else
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

		glEnable(GL_LIGHTING);
		glPushMatrix();

		cml::SE3 &se3 = motion.m_obj_motion[frame - motion.frame_offset];
		glMultMatrixd(se3.data());

		glScaled(motion.m_obj_size[0], motion.m_obj_size[1], motion.m_obj_size[2]);
		GetObjectRenderer().Render((ObjectRenderer::TYPE) motion.m_obj_type, colorful);

		glPopMatrix();
		
		glDisable(GL_LIGHTING);
		glDisable(GL_BLEND);
	}
	
}