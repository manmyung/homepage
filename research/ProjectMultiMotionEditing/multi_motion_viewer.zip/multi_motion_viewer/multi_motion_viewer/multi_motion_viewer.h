#pragma once

#include "multi_motion.h"
#include "basiclib_gui/fl_movie.h"

class Multi_motion_viewer : public Fl_movie
{
public:
	Multi_motion_viewer(Multi_motion *mm_);
	~Multi_motion_viewer(void);

	void draw_();
	void draw_motion(Motion &mo, double frame, bool colorful);

	Multi_motion *mm;
};
