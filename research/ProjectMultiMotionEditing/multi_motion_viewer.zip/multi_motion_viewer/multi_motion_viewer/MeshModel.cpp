#include "MeshModel.h"
#include <GL/glut.h>
#include <iostream>
#include <fstream>
#include <float.h>

#pragma warning(disable:4244)

using namespace std;

MeshModel::MeshModel()
{
	model_name.clear();
}

MeshModel::~MeshModel()
{
	model_name.clear();
	index.clear();
	vertex.clear();
	normal.clear();

	if( pVertices != NULL )
		for( int i = 0; i < Vtx.numVertex; i++ )
			delete [] pVertices[i];
	delete [] pVertices;

	if( pNormals != NULL )
		for( int i = 0; i < Vtx.numNormal; i++ )
			delete [] pNormals[i];
	delete [] pNormals;

	if( pTex != NULL )
		for( int i = 0; i < Vtx.numTex; i++ )
			delete [] pTex[i];
	delete [] pTex;

	if( pFaces != NULL )
		for( int i = 0; i < Vtx.numFace; i++ )
			delete [] pFaces[i];
	delete [] pFaces;
}

void
MeshModel::loadModel()
{
	loadModel("model data/");
}


void
MeshModel::createModel(std::string name)
{
	createModel("model data/", name);


}


void
MeshModel::loadModel(std::string path)
{
	ifstream		fin;
	std::string	name;

	int i,j;
	char ch[100];

	index.clear();
	vertex.clear();
	normal.clear();

	cout << "Creating [" << model_name.data() << "] Model......" << endl;

	name.clear();
	name.assign(path);
	name.append(model_name);
	name.append("_index.txt");
	fin.open(name.data());
	if ( fin.fail() ) printf("error opening %s\n", name.data());

	fin >> ch;	index_N = atoi(ch);	

	for(i=0;i<index_N;i++)
	{
		std::vector<int> temp(9);
		for(j=0;j<9;j++)		{	fin >> ch;	temp[j] = atoi(ch);	}
		index.push_back(temp);
	}

	fin.close();
	fin.clear();

	name.clear();
	name.assign(path);
	name.append(model_name);
	name.append("_vertex.txt");
	fin.open(name.data());
	if ( fin.fail() ) printf("error opening %s\n", name.data());

	fin >> ch;	vertex_N = atoi(ch);	

	for(i=0;i<vertex_N;i++)
	{
		std::vector<float> temp(3);
		for(j=0;j<3;j++)		{	fin >> ch;		temp[j] = (float)atof(ch);	}
		vertex.push_back(temp);
	}
	fin.close();		
	fin.clear();

	name.clear();
	name.assign(path);
	name.append(model_name);
	name.append("_normal.txt");
	fin.open(name.data());
	if ( fin.fail() ) printf("error opening %s\n", name.data());

	fin >> ch;	normal_N = atoi(ch);	

	for(i=0;i<normal_N;i++)
	{
		std::vector<float> temp(3);
		for(j=0;j<3;j++)		{	fin >> ch;		temp[j] = (float)atof(ch);	}
		normal.push_back(temp);
	}

	fin.close();
	fin.clear();

	name.clear();
	name.assign(path);
	name.append(model_name);
	name.append("_texture.txt");
	fin.open(name.data());

	if (fin.fail()) printf("error opening %s\n", name.data());

	fin >> ch; text_coord_N = atoi(ch);

	for (i = 0; i< text_coord_N; i++)
	{
		std::vector<float> temp(2); 
		for (j =0; j< 2; j++){
			fin >> ch; 
			temp[j] = (float)atof(ch);
			//cout << temp[j] << "  ";
			text_coord.push_back(temp);
		}
		//cout << endl; 
	}
	fin.close();
	fin.clear();

	cout << "Complete creating!" << endl;
}


void
MeshModel::createModel(std::string path, std::string name)
{
	int i;

	model_name.assign(name);
	
	for(i=0;i<3;i++)	
		color[i]		= (rand()%101)/100.0f;


	loadModel(path);
}


void
MeshModel::setColor(float r, float g, float b)
{
	color[0] = r;
	color[1] = g;
	color[2] = b;
}

void
MeshModel::displayModel()
{
	int i,j,vi,ni;

	glBegin (GL_TRIANGLES);
	for(i=0;i<index_N;i++)
	for(j=0;j<3;j++)
	{
		vi	=	index[i][j];
		ni	=	index[i][j+3];

		glNormal3f (normal[ni][0],normal[ni][1],normal[ni][2]);
		glVertex3f (vertex[vi][0],vertex[vi][1],vertex[vi][2]);
	}
    glEnd ();

}

void MeshModel::loadTexture( std::string path )
{	
	Image texture;
	
	if (ImageLoad(path.c_str(), &texture) == 0)
		return;

	// Generate a texture with the associative texture ID stored in the array
	glGenTextures(1, &texId);

	// This sets the alignment requirements for the start of each pixel row in memory.
	glPixelStorei (GL_UNPACK_ALIGNMENT, 1);

	// Bind the texture to the texture arrays index and init the texture
	glBindTexture(GL_TEXTURE_2D, texId);

	// Build Mipmaps (builds different versions of the picture for distances - looks better)
	gluBuild2DMipmaps(GL_TEXTURE_2D, 3, texture.sizeX, texture.sizeY, GL_RGB, GL_UNSIGNED_BYTE, texture.data);

	// Lastly, we need to tell OpenGL the quality of our texture map.  GL_LINEAR_MIPMAP_LINEAR
	// is the smoothest.  GL_LINEAR_MIPMAP_NEAREST is faster than GL_LINEAR_MIPMAP_LINEAR, 
	// but looks blochy and pixilated.  Good for slower computers though.  

	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR_MIPMAP_LINEAR);
}

void MeshModel::displayModelWithTexture()
{
	glBindTexture(GL_TEXTURE_2D, texId);
	glBegin(GL_TRIANGLES);
	if( Vtx.numNormal == 0 ){
		for(int ix = 0; ix < Vtx.numFace; ix++ ){
			glTexCoord2fv( pTex[ pFaces[ix][3] - 1 ] );
			glVertex3fv( pVertices[ pFaces[ix][0] - 1 ]);

			glTexCoord2fv( pTex[ pFaces[ix][4] - 1 ] );
			glVertex3fv( pVertices[ pFaces[ix][1] - 1 ]);

			glTexCoord2fv( pTex[ pFaces[ix][5] - 1 ] );
			glVertex3fv( pVertices[ pFaces[ix][2] - 1 ]);		
		}
	}else if( Vtx.numTex == 0){
		for(int ix = 0; ix < Vtx.numFace; ix++ ){
			glNormal3fv( pNormals[ pFaces[ix][3] - 1 ] );
			glVertex3fv( pVertices[ pFaces[ix][0] - 1 ]);

			glNormal3fv( pNormals[ pFaces[ix][4] - 1 ] );
			glVertex3fv( pVertices[ pFaces[ix][1] - 1 ]);

			glNormal3fv( pNormals[ pFaces[ix][5] - 1 ] );
			glVertex3fv( pVertices[ pFaces[ix][2] - 1 ]);
		}
	}else if( Vtx.numNormal == 0 && Vtx.numTex == 0 ){
		for(int ix = 0; ix < Vtx.numFace; ix++ ){
			glVertex3fv( pVertices[ pFaces[ix][0] - 1 ]);
			glVertex3fv( pVertices[ pFaces[ix][1] - 1 ]);
			glVertex3fv( pVertices[ pFaces[ix][2] - 1 ]);
		}
	}else{
		for(int ix = 0; ix < Vtx.numFace; ix++ ){
			glNormal3fv( pNormals[ pFaces[ix][6] - 1 ] );
			glTexCoord2fv( pTex[ pFaces[ix][3] - 1 ] );	
			glVertex3fv( pVertices[ pFaces[ix][0] - 1 ]);

			glNormal3fv( pNormals[ pFaces[ix][7] - 1 ] );
			glTexCoord2fv( pTex[ pFaces[ix][4] - 1 ] );	
			glVertex3fv( pVertices[ pFaces[ix][1] - 1 ]);

			glNormal3fv( pNormals[ pFaces[ix][8] - 1 ] );
			glTexCoord2fv( pTex[ pFaces[ix][5] - 1 ] );	
			glVertex3fv( pVertices[ pFaces[ix][2] - 1 ]);
		}
	}
	glEnd();
}

void MeshModel::loadObjFile(std::string path)
{
	FILE* objfile = fopen(path.c_str(),"r");
	if (objfile == NULL){
		cout << "can not open obj file !!" << endl; 
		return; 
	}
	countTokens(path);
	allocateArrays();
	parseFile(path);
	fclose(objfile);
}

void MeshModel::countTokens(std::string path) {
	
	Vtx.numVertex = 0;
	Vtx.numTex = 0;
	Vtx.numNormal = 0;
	Vtx.numFace = 0;

	char str[256];
	std::ifstream objFile;

	objFile.open(path.c_str());

	while( objFile.good() ){
		objFile.getline(str, 256);

		switch(str[0]){
			case 'v':
				if( str[1] == ' ' )
					Vtx.numVertex++;
				else if( str[1] == 't' )
					Vtx.numTex++;
				else if( str[1] == 'n' )
					Vtx.numNormal++;

				break;
			case 'f':
				Vtx.numFace++;
				break;
				// �������� ���ϱ����� ���� �� �߰��Ѵ�
		}
	}

	objFile.close(); 
}
bool MeshModel::allocateArrays()
{
	if( pVertices == NULL ){
		pVertices = new float *[Vtx.numVertex];
		for( int i = 0; i < Vtx.numVertex; i++ )
			pVertices[i] = new float[DIM];
	}
	if( pVertices == NULL )
		return false;

	if( Vtx.numTex == 0) {
		pTex = NULL;

		if( pNormals == NULL ){
			pNormals = new float *[Vtx.numNormal];
			for( int i = 0; i < Vtx.numNormal; i++ )
				pNormals[i] = new float[DIM];
		}
		if( pNormals == NULL )
			return false;

		if( pFaces == NULL ){
			pFaces = new int *[Vtx.numFace];
			for( int i = 0; i < Vtx.numFace; i++ )
				pFaces[i] = new int[DIM * 2];
		}
		if( pFaces == NULL )
			return false;
	}else{
		if( pTex == NULL ){
			pTex = new float *[Vtx.numTex];
			for( int i = 0; i < Vtx.numTex; i++ )
				pTex[i] = new float[2];
		}
		if( pTex == NULL )
			return false;

		if( pNormals == NULL ){
			pNormals = new float *[Vtx.numNormal];
			for( int i = 0; i < Vtx.numNormal; i++ )
				pNormals[i] = new float[DIM];
		}
		if( pNormals == NULL )
			return false;

		if( pFaces == NULL ){
			pFaces = new int *[Vtx.numFace];
			for( int i = 0; i < Vtx.numFace; i++ )
				pFaces[i] = new int[DIM * 3];
		}
		if( pFaces == NULL )
			return false;
	}
	return true;
}
void MeshModel::parseFile(std::string file_path)
{
	int curVtx = 0;
	int curNormal = 0; 
	int curTexCoord = 0;
	int curFace = 0;
	int temp;

	char fileLine[256];
	std::ifstream objFile;
	
	objFile.open(file_path.c_str());

	float min_x = FLT_MAX;
	float min_y = FLT_MAX;
	float min_z = FLT_MAX;

	float max_x = FLT_MIN;
	float max_y = FLT_MIN;
	float max_z = FLT_MIN;

	while( objFile.good() ){
		objFile.getline(fileLine, 256);

		if (fileLine[0] == 'v') {
			if (fileLine[1] == ' ') {
				sscanf(fileLine, "v %f %f %f", &(pVertices[curVtx][0]), &(pVertices[curVtx][1]), &(pVertices[curVtx][2]));

				// x
				if (min_x > pVertices[curVtx][0]) min_x = pVertices[curVtx][0];
				if (max_x < pVertices[curVtx][0]) max_x = pVertices[curVtx][0];
				
				// y
				if (min_y > pVertices[curVtx][1]) min_y = pVertices[curVtx][1];
				if (max_y < pVertices[curVtx][1]) max_y = pVertices[curVtx][1];
				
				// z
				if (min_z > pVertices[curVtx][2]) min_z = pVertices[curVtx][2];
				if (max_z < pVertices[curVtx][2]) max_z = pVertices[curVtx][2];
				
				++curVtx;
			}
			else if (fileLine[1] == 't') {
				sscanf(fileLine, "vt %f %f", &(pTex[curTexCoord][0]), &(pTex[curTexCoord][1]));
				++curTexCoord;
			}
			else if(fileLine[1] == 'n'){
				sscanf(fileLine, "vn %f %f %f", &pNormals[curNormal][0], &pNormals[curNormal][1], &pNormals[curNormal][2] );
				curNormal++;
			}
		}
		else if (fileLine[0] == 'f') {

			if( Vtx.numNormal == 0 ){
				sscanf(fileLine, "f %d/%d %d/%d %d/%d", &pFaces[curFace][0], &pFaces[curFace][3],
					&pFaces[curFace][1], &pFaces[curFace][4],
					&pFaces[curFace][2], &pFaces[curFace][5]);
			}
			else if( Vtx.numTex == 0 ){
				sscanf(fileLine, "f %d//%d %d//%d %d//%d", &pFaces[curFace][0], &pFaces[curFace][3],
					&pFaces[curFace][1], &pFaces[curFace][4],
					&pFaces[curFace][2], &pFaces[curFace][5]);
			}
			else if( Vtx.numNormal == 0 && Vtx.numTex == 0 ){
				sscanf(fileLine, "f %d %d %d", &pFaces[curFace][0], &pFaces[curFace][1], &pFaces[curFace][2] );

			}
			else
			{
				sscanf(fileLine, "f %d/%d/%d %d/%d/%d %d/%d/%d", &pFaces[curFace][0], &pFaces[curFace][3], &pFaces[curFace][6],
					&pFaces[curFace][1], &pFaces[curFace][4], &pFaces[curFace][7],
					&pFaces[curFace][2], &pFaces[curFace][5], &pFaces[curFace][8]);
			}
			++curFace;
		}
	}

	model_center[0] = (max_x + min_x) / 2.0;
	model_center[1] = (max_y + min_y) / 2.0 + max_y;
	model_center[2] = (max_z + min_z) / 2.0;

	objFile.close();
}
