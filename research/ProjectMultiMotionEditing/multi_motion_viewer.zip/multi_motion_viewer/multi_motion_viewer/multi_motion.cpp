#include "multi_motion.h"

Motion::Motion( void ) 
{
	frame_offset = 0;
}

Motion::Motion( const Motion &other )
{
	m_is_human = other.m_is_human; 
	memcpy(m_color, other.m_color, sizeof(m_color));
	memcpy(m_obj_size, other.m_obj_size, sizeof(m_obj_size));
	m_obj_type = other.m_obj_type;
	frame_offset = other.frame_offset;

	if (other.m_is_human == true) {
		m_pm_motion = new PmLinearMotion();
		copy_motion(m_pm_motion, other.m_pm_motion);
	}
	else {
		m_obj_motion = other.m_obj_motion;	
	}
}

Motion::~Motion( void )
{
}

#include <fstream>
void Motion::load( const std::string & file_name, bool is_bvh /*= false*/ )
{
	if (is_bvh == false) // load mov, amc files
	{
		std::ifstream file( file_name.c_str(), std::ios::in );
		if ( file.fail() ) {
			cout << "no mot file" << endl;
			return;
		}
		
		bool motion_loaded = false;

		std::string keyword;
		while ( file.eof() == false)
		{
			file >> keyword;
			if (keyword == ":is_human")
			{
				file >> m_is_human;
			}
			if (keyword == ":color")
			{
				file >> m_color[0] >> m_color[1] >> m_color[2] >> m_color[3];
			}
			if (keyword == ":obj_size")
			{
				file >> m_obj_size[0] >> m_obj_size[1] >> m_obj_size[2];
			}
			if (keyword == ":obj_type")
			{
				file >> m_obj_type;
			}
			if (keyword == ":motion" && motion_loaded == false)
			{
				int motion_size;
				file >> motion_size;

				if (m_is_human == true)
				{
					std::string amc_file_name = file_name;
					amc_file_name.replace(amc_file_name.size()-4, 4, ".amc");
					m_pm_motion = get_motion("../data/wd2.actor", (char *) (amc_file_name).c_str());	
				}
				else
				{
					for (int frame = 0; frame < motion_size; frame++)
					{
						cml::SE3 se3;
						for (int se3_i = 0; se3_i < 4; se3_i++) {
							for (int se3_j = 0; se3_j < 4; se3_j++) {
								file >> se3(se3_i,se3_j);
							}
						}
						m_obj_motion.push_back(se3);
					}
				}

				motion_loaded = true;
			}
		}

		file.close();
	}
	else // load bvh files 
	{
		m_is_human = true;
		m_color[0] = 0.2;
		m_color[1] = 0.5;
		m_color[2] = 0.2;
		m_color[3] = 1.0;

		//To use BVH in PmQm(motion) library, you should make joint mapping file.  
		m_pm_motion = get_bvhmotion("../data/woody_joint_mapping.txt", (char *) (file_name).c_str(), 0.027 / 2.6);
		m_pm_motion->applyTransf(jhm::translate_transf(0, 1.00, 0)); 
	}
}


int Motion::get_first_frame()
{
	if (frame_offset < 0)
		return 0;
	else
		return frame_offset;
}

int Motion::get_last_frame()
{
	int motion_size;

	if (m_is_human == true)
		motion_size = m_pm_motion->getSize();
	else
		motion_size = m_obj_motion.size();

	return (motion_size - 1) + frame_offset;
}

void Motion::translate( double x, double y, double z )
{
	if (m_is_human == true) {
		jhm::vector transV(x, y, z);
		for (int i = 0; i < m_pm_motion->getSize(); ++i)
		{
			m_pm_motion->getPosture(i).addTranslation(transV);
		}
	}
	else {
		for (int i = 0; i < m_obj_motion.size(); ++i) {
			cml::SE3 &se3 = m_obj_motion[i];
			se3(0,3) += x;
			se3(1,3) += y;
			se3(2,3) += z;
		}
	}
}

void Motion::rotate( double radian )
{
	if (m_is_human == true) {
		m_pm_motion->applyTransf(jhm::transf(jhm::exp(jhm::vector(0, radian / 2.0, 0)), jhm::vector(0,0,0)));
	}
	else {
		for (int i = 0; i < m_obj_motion.size(); ++i) {
			cml::SE3 &se3 = m_obj_motion[i];
			cml::SE3 rotSe3 = getSE3ByRotY(radian);
			se3 = rotSe3 * se3;
		}
	}
}

void Motion::translate_time( int frame )
{
	frame_offset += frame;
}

Multi_motion::Multi_motion(void)
{
	frame_rate = 30;
}

Multi_motion::~Multi_motion(void)
{
}

#include <io.h>
void Multi_motion::load( const std::string & folder_name, bool is_bvh /*= false*/ )
{
	long                     hFile;
	struct _finddata_t       stFileInfo;

	if (is_bvh == false)
	{
		hFile = _findfirst((folder_name + "*.mot").c_str(), &stFileInfo);
	}
	else
	{
		hFile = _findfirst((folder_name + "*.bvh").c_str(), &stFileInfo);
		frame_rate = 60;
	}

	if (-1L == hFile)
	{
		cout << "load_hFile error" << endl;
		return;
	}

	do {
		std::string file_name(stFileInfo.name);
		if (file_name[file_name.size()-1] == '~') 
			continue;
		cout << "load: " << file_name << endl;

		Motion motion;
		motion.load(folder_name+file_name, is_bvh);
		m_motions.push_back(motion);

	} while (0 == _findnext(hFile, &stFileInfo));

}

int Multi_motion::get_last_frame()
{	
	int max_size = 0;
	for (std::vector<Motion>::iterator iter = m_motions.begin(); iter != m_motions.end(); ++iter) {
		int size = iter->get_last_frame();
		if (size > max_size)
			max_size = size;
	}
	return max_size;
}

void Multi_motion::add( Multi_motion & other )
{
	for (std::vector<Motion>::iterator iter = other.m_motions.begin(); iter != other.m_motions.end(); ++iter) {
		m_motions.push_back(*iter);
	}
}

void Multi_motion::translate( double x, double y, double z )
{
	for (std::vector<Motion>::iterator iter = m_motions.begin(); iter != m_motions.end(); ++iter) {
		iter->translate(x, y, z);
	}
}

void Multi_motion::rotate( double radian )
{
	for (std::vector<Motion>::iterator iter = m_motions.begin(); iter != m_motions.end(); ++iter) {
		iter->rotate(radian);
	}
}

void Multi_motion::translate_time( int frame )
{
	for (std::vector<Motion>::iterator iter = m_motions.begin(); iter != m_motions.end(); ++iter) {
		iter->translate_time(frame);
	}
}