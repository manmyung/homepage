# pragma once

#include "bitmap.h"
#include "bmpLoader.h"
#include <vector>

#define DIM 3


typedef struct ModelInfo
{
	int numVertex;
	int numNormal;
	int numTex;
	int numFace;
}MODEL;

class
MeshModel
{
public:
	std::string						model_name;
	
	int									index_N;			
	int									vertex_N;			
	int									normal_N;	
	int									text_coord_N;

	float								color[3];

	std::vector< std::vector<int> >			index;
	std::vector< std::vector<float> >		vertex;
	std::vector< std::vector<float> >		normal;
	std::vector< std::vector<float> >       text_coord; 

	MeshModel();
	~MeshModel();
	
	void								createModel(std::string name);
	void								createModel(std::string path, std::string name);

	void								setColor(float r, float g, float b);
	

	void								loadModel();
	void								loadModel(std::string path);
	void								displayModel();


	void								loadObjFile(std::string path);
	void                                loadTexture(std::string path);
	void								displayModelWithTexture(); 
	void								countTokens(std::string path);
	bool								allocateArrays();
	void								parseFile(std::string file_path);

	float model_center[DIM];

private:

	float ** pVertices; 
	float ** pNormals; 
	float ** pTex; 
	int   ** pFaces; 

	MODEL Vtx;
	unsigned char* bitmapData;
	unsigned int texId;
};