#include "multi_motion.h"
#include "multi_motion_viewer.h"

void motion_load(Multi_motion & mm_)
{
	//mm_.load("../data/save/1/");
	//mm_.load("../data/save/2/"); //hivefive1
	//mm_.load("../data/save/3/"); //hivefive2
	//mm_.load("../data/save/4/");
	//mm_.load("../data/save/5/");
	//mm_.load("../data/save/6/"); //chair
	//mm_.load("../data/save/7/"); //push, pull
	//mm_.load("../data/save/8/"); //car
	//mm_.load("../data/save/9/"); //box_relay
	//mm_.load("../data/save/10/"); //box_relay many
	//mm_.load("../data/save/11/"); //house init
	mm_.load("../data/save/12/"); //house 
	//mm_.load("../data/RenderedMotion/", true);
}

void example1(Multi_motion & mm)
{
	mm.load("../data/save/6/");
	mm.rotate(3.1415/2);
	mm.translate(0,0,-3);
}

void example2(Multi_motion & mm)
{
	Multi_motion mm1;
	mm1.load("../data/save/6/");
	
	Multi_motion mm1_copy = mm1; // copy
	mm1_copy.translate_time(30);
	
	mm.add(mm1);
	mm.add(mm1_copy);
}

void example3(Multi_motion & mm)
{
	Multi_motion mm1;
	mm1.load("../data/save/6/");

	for (int i = 0; i < 10; i++) {
		Multi_motion mm1_copy = mm1; 
		mm1_copy.rotate(i * 0.63);
		mm.add(mm1_copy);
	}
}

void example4(Multi_motion & mm)
{
	Multi_motion mm_;
	mm_.load("../data/save/2/");

	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			Multi_motion mm_copy = mm_; 
			mm_copy.rotate((i + j) * 3.14/ 8);
			mm_copy.translate(-5 + i*2.5, 0, -6 + j*2.5);
			mm_copy.translate_time((i+j) * 20);
			mm.add(mm_copy);
		}
	}
}

void example5(Multi_motion & mm)
{
	{
		Multi_motion mm_;
		mm_.load("../data/save/7/");
		mm.add(mm_);
	}

	{
		Multi_motion mm_;
		mm_.load("../data/save/2/");
		mm.add(mm_);
	}

	{
		Multi_motion mm_;
		mm_.load("../data/save/9/");
		mm.add(mm_);
	}

	{
		Multi_motion mm_;
		mm_.load("../data/save/12/");

		for (int i = 0; i < 5; i++) {
			Multi_motion mm_copy = mm_; 
			mm_copy.rotate(i * 1.26);
			mm_copy.translate_time(-i * 60);
			mm.add(mm_copy);
		}
	}
}


void motion_load_and_manipulate(Multi_motion & mm)
{
	//example1(mm);
	//example2(mm);
	//example3(mm);
	//example4(mm);
	example5(mm);
}

int main(int argc, char **argv) { 
	Multi_motion mm;
	//motion_load(mm);
	motion_load_and_manipulate(mm);

	Multi_motion_viewer mmv(&mm);
	return Fl::run();
}
