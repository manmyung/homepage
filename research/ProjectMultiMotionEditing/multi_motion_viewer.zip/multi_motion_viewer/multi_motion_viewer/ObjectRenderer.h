#pragma once

#include "MeshModel.h"

class ObjectRenderer
{
public:
	enum TYPE {
		SOLID_CUBE,
		SOLID_SPHERE,
		CHAIR,
		YUGO_45,
		FLIGHT,
		BENCH,
	};
	~ObjectRenderer(void);

	static ObjectRenderer& GetInstance() {
		static ObjectRenderer _instance;
		return _instance;
	}
	void Render(TYPE type, bool color);

protected:
	void LoadChair();
	void LoadYugo();
	void LoadBench();

	ObjectRenderer(void);
	
	MeshModel m_chair, m_yugo45, m_fight, m_bench;
	int m_chairListIndex, m_yugo45ListIndex, m_flightListIndex, m_benchListIndex;
};

inline ObjectRenderer &GetObjectRenderer() { return ObjectRenderer::GetInstance(); }