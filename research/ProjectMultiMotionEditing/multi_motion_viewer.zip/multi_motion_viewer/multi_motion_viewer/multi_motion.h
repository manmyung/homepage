#pragma once
#include "basiclib/basiclib.h"
#include "pmqm_wrapper/pmqm_wrapper.h"

#include <map>
#include <vector>
#include <string>

class Motion
{
public:
	Motion(void);
	~Motion(void);
	Motion(const Motion &other);

	void load(const std::string & file_name, bool is_bvh = false);
	int get_first_frame();
	int get_last_frame();
	
	void translate(double x, double y, double z);
	void rotate(double radian);
	void translate_time(int frame);
	
	PmLinearMotion * m_pm_motion;		//human motion
	std::vector<cml::SE3> m_obj_motion;	//object motion

	bool m_is_human; //true : human, false : object
	double m_color[4];

	double m_obj_size[3];
	int m_obj_type;

	int frame_offset;
};	 

class Multi_motion
{
public:
	Multi_motion(void);
	~Multi_motion(void);

	void load(const std::string & folder_name, bool is_bvh = false);
	int get_last_frame();

	void add(Multi_motion & other);
	void translate(double x, double y, double z);
	void rotate(double radian);
	void translate_time(int frame);

	std::vector<Motion> m_motions;
	int frame_rate;
};